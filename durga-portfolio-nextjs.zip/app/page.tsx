import { profile } from "@/data/profile";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Badge } from "@/components/Badge";
import { ProjectFilters } from "@/components/ProjectFilters";

export default function HomePage() {
  return (
    <main>
      {/* Hero */}
      <section className="py-14 sm:py-20">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
            <div>
              <div className="flex flex-wrap gap-2">
                <Badge>{profile.location}</Badge>
                <Badge>{profile.headline}</Badge>
              </div>

              <h1 className="mt-5 text-4xl font-semibold tracking-tight sm:text-5xl">
                {profile.name}
              </h1>
              <p className="mt-4 max-w-2xl text-lg text-zinc-600 dark:text-zinc-300">
                {profile.summary}
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                <a
                  href="#projects"
                  className="rounded-full bg-zinc-900 px-5 py-3 text-sm font-medium text-white no-underline shadow-soft hover:opacity-90 dark:bg-white dark:text-zinc-900"
                >
                  View Projects
                </a>
                <a
                  href="/resume.pdf"
                  className="rounded-full border border-zinc-200 bg-white px-5 py-3 text-sm font-medium no-underline shadow-soft hover:shadow dark:border-zinc-800 dark:bg-zinc-950"
                >
                  Download Resume
                </a>
                <a
                  href={`mailto:${profile.email}`}
                  className="rounded-full border border-zinc-200 bg-white px-5 py-3 text-sm font-medium no-underline shadow-soft hover:shadow dark:border-zinc-800 dark:bg-zinc-950"
                >
                  Email Me
                </a>
              </div>

              <div className="mt-6 flex flex-wrap gap-4 text-sm text-zinc-600 dark:text-zinc-400">
                <span>{profile.email}</span>
                <span>•</span>
                <a className="hover:underline" href={`https://www.linkedin.com/in/${profile.linkedin}`} target="_blank" rel="noreferrer">
                  linkedin.com/in/{profile.linkedin}
                </a>
              </div>
            </div>

            {/* Quick facts */}
            <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
                Quick facts
              </h2>
              <ul className="mt-4 space-y-3 text-sm">
                <li className="flex items-start justify-between gap-4">
                  <span className="text-zinc-600 dark:text-zinc-400">Current</span>
                  <span className="text-right">{profile.education[0].degree}</span>
                </li>
                <li className="flex items-start justify-between gap-4">
                  <span className="text-zinc-600 dark:text-zinc-400">Experience</span>
                  <span className="text-right">3+ years (TCS)</span>
                </li>
                <li className="flex items-start justify-between gap-4">
                  <span className="text-zinc-600 dark:text-zinc-400">Focus</span>
                  <span className="text-right">AI / NLP • Cloud • Automation</span>
                </li>
                <li className="flex items-start justify-between gap-4">
                  <span className="text-zinc-600 dark:text-zinc-400">Open to</span>
                  <span className="text-right">Internships / New grad roles</span>
                </li>
              </ul>
            </div>
          </div>
        </Container>
      </section>

      {/* About */}
      <Section
        id="about"
        title="About"
        subtitle="A snapshot of who I am and what I like to build."
      >
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 rounded-2xl border border-zinc-200 bg-white p-6 shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
            <p className="text-zinc-700 dark:text-zinc-200">
              {profile.summary}
            </p>
            <p className="mt-3 text-zinc-600 dark:text-zinc-300">
              My recent work includes an AI-driven job analyzer that matches resumes to job descriptions using semantic similarity,
              plus projects in computer vision and embedded systems.
            </p>
          </div>

          <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">Highlights</h3>
            <ul className="mt-4 space-y-2 text-sm text-zinc-700 dark:text-zinc-200">
              <li>• NLP + semantic matching</li>
              <li>• AWS deployment + infra-as-code</li>
              <li>• Practical automation and debugging</li>
              <li>• Clear communication & delivery</li>
            </ul>
          </div>
        </div>
      </Section>

      {/* Skills */}
      <Section id="skills" title="Skills" subtitle="Tools I use to build, ship, and maintain reliable systems.">
        <div className="grid gap-4 sm:grid-cols-2">
          {Object.entries(profile.skills).map(([group, items]) => (
            <div key={group} className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
              <h3 className="text-base font-semibold">{group}</h3>
              <div className="mt-3 flex flex-wrap gap-2">
                {items.map((s) => (
                  <Badge key={s}>{s}</Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Projects */}
      <Section id="projects" title="Projects" subtitle="Selected work. Click a project to see details.">
        <ProjectFilters />
      </Section>

      {/* Experience */}
      <Section id="experience" title="Experience" subtitle="Industry experience and internships.">
        <div className="space-y-4">
          {profile.experience.map((job) => (
            <div key={job.company} className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
              <div className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
                <div>
                  <h3 className="text-lg font-semibold">{job.title}</h3>
                  <p className="text-sm text-zinc-600 dark:text-zinc-300">{job.company} • {job.where}</p>
                </div>
                <p className="text-sm text-zinc-500 dark:text-zinc-400">{job.when}</p>
              </div>
              <ul className="mt-4 list-disc space-y-2 pl-5 text-sm text-zinc-700 dark:text-zinc-200">
                {job.bullets.map((b) => (
                  <li key={b}>{b}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      {/* Education */}
      <Section id="education" title="Education" subtitle="Academic background and relevant coursework.">
        <div className="grid gap-4">
          {profile.education.map((ed) => (
            <div key={ed.school} className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
              <div className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
                <div>
                  <h3 className="text-lg font-semibold">{ed.degree}</h3>
                  <p className="text-sm text-zinc-600 dark:text-zinc-300">{ed.school} • {ed.where}</p>
                </div>
                <p className="text-sm text-zinc-500 dark:text-zinc-400">{ed.when}</p>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {ed.coursework.map((c) => (
                  <Badge key={c}>{c}</Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Certifications + Achievements */}
      <Section title="Certifications & Achievements" subtitle="Credentials and recognition.">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
            <h3 className="text-base font-semibold">Certifications</h3>
            <ul className="mt-4 list-disc space-y-2 pl-5 text-sm text-zinc-700 dark:text-zinc-200">
              {profile.certifications.map((c) => (
                <li key={c}>{c}</li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
            <h3 className="text-base font-semibold">Achievements</h3>
            <ul className="mt-4 list-disc space-y-2 pl-5 text-sm text-zinc-700 dark:text-zinc-200">
              {profile.achievements.map((a) => (
                <li key={a}>{a}</li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      {/* Contact */}
      <Section
        id="contact"
        title="Contact"
        subtitle="Want to collaborate or chat about a role? Send me a message."
      >
        <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <h3 className="text-lg font-semibold">Let’s talk</h3>
              <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-300">
                Email is the fastest way to reach me. If you prefer LinkedIn, feel free to connect.
              </p>
              <div className="mt-4 flex flex-wrap gap-3">
                <a
                  href={`mailto:${profile.email}?subject=Portfolio%20Inquiry`}
                  className="rounded-full bg-zinc-900 px-5 py-3 text-sm font-medium text-white no-underline shadow-soft hover:opacity-90 dark:bg-white dark:text-zinc-900"
                >
                  Email
                </a>
                <a
                  href={`https://www.linkedin.com/in/${profile.linkedin}`}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-zinc-200 bg-white px-5 py-3 text-sm font-medium no-underline shadow-soft hover:shadow dark:border-zinc-800 dark:bg-zinc-950"
                >
                  LinkedIn
                </a>
              </div>
            </div>
            <div className="rounded-2xl border border-zinc-200 bg-zinc-50 p-5 dark:border-zinc-800 dark:bg-zinc-900/30">
              <h4 className="text-sm font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">Details</h4>
              <dl className="mt-4 space-y-3 text-sm">
                <div>
                  <dt className="text-zinc-600 dark:text-zinc-400">Location</dt>
                  <dd>{profile.location}</dd>
                </div>
                <div>
                  <dt className="text-zinc-600 dark:text-zinc-400">Email</dt>
                  <dd>{profile.email}</dd>
                </div>
                <div>
                  <dt className="text-zinc-600 dark:text-zinc-400">Phone</dt>
                  <dd>{profile.phone}</dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
      </Section>
    </main>
  );
}
