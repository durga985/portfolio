import Link from "next/link";
import { Container } from "@/components/Container";
import { ThemeToggle } from "@/components/ThemeToggle";
import { profile } from "@/data/profile";

const links = [
  { href: "#about", label: "About" },
  { href: "#skills", label: "Skills" },
  { href: "#projects", label: "Projects" },
  { href: "#experience", label: "Experience" },
  { href: "#education", label: "Education" },
  { href: "#contact", label: "Contact" },
];

export function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-zinc-200 bg-white/70 backdrop-blur dark:border-zinc-800 dark:bg-zinc-950/50">
      <Container className="flex items-center justify-between py-3">
        <div className="flex items-center gap-3">
          <Link href="/" className="no-underline">
            <span className="rounded-full border border-zinc-200 bg-white px-3 py-1 text-sm font-semibold shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
              {profile.name.split(" ")[0]}
            </span>
          </Link>
          <nav className="hidden md:flex items-center gap-4 text-sm">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-zinc-700 no-underline hover:text-zinc-900 dark:text-zinc-300 dark:hover:text-white"
              >
                {l.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="/resume.pdf"
            className="hidden sm:inline-flex rounded-full border border-zinc-200 bg-white px-3 py-2 text-sm shadow-soft no-underline hover:shadow dark:border-zinc-800 dark:bg-zinc-950"
          >
            Resume
          </a>
          <ThemeToggle />
        </div>
      </Container>
    </header>
  );
}
