import Link from "next/link";
import { Badge } from "@/components/Badge";
import { cn } from "@/lib/utils";

export function ProjectCard({
  slug,
  name,
  tagline,
  stack,
  className,
}: {
  slug: string;
  name: string;
  tagline: string;
  stack: readonly string[];
  className?: string;
}) {
  return (
    <Link
      href={`/projects/${slug}`}
      className={cn(
        "group block rounded-2xl border border-zinc-200 bg-white p-5 shadow-soft no-underline transition hover:-translate-y-0.5 hover:shadow dark:border-zinc-800 dark:bg-zinc-950",
        className
      )}
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-lg font-semibold tracking-tight group-hover:underline">{name}</h3>
          <p className="mt-1 text-sm text-zinc-600 dark:text-zinc-300">{tagline}</p>
        </div>
        <span className="text-sm text-zinc-500 dark:text-zinc-400">View →</span>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {stack.slice(0, 6).map((s) => (
          <Badge key={s}>{s}</Badge>
        ))}
        {stack.length > 6 ? <Badge className="opacity-80">+{stack.length - 6}</Badge> : null}
      </div>
    </Link>
  );
}
