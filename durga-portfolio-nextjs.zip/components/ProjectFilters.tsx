"use client";

import { useMemo, useState } from "react";
import { Badge } from "@/components/Badge";
import { ProjectCard } from "@/components/ProjectCard";
import { profile } from "@/data/profile";

type Project = (typeof profile.projects)[number];

function uniq<T>(arr: T[]) {
  return Array.from(new Set(arr));
}

export function ProjectFilters() {
  const projects = profile.projects;
  const allTags = useMemo(() => uniq(projects.flatMap((p) => p.stack)).sort(), [projects]);
  const [active, setActive] = useState<string>("All");
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const base = projects.filter((p) => (active === "All" ? true : p.stack.includes(active)));
    const query = q.trim().toLowerCase();
    if (!query) return base;
    return base.filter((p) => (p.name + " " + p.tagline + " " + p.highlights.join(" ")).toLowerCase().includes(query));
  }, [projects, active, q]);

  return (
    <div>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setActive("All")}
            className="rounded-full border border-zinc-200 bg-white px-3 py-2 text-sm shadow-soft hover:shadow dark:border-zinc-800 dark:bg-zinc-950"
          >
            All
          </button>
          {allTags.slice(0, 10).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setActive(t)}
              className="rounded-full border border-zinc-200 bg-white px-3 py-2 text-sm shadow-soft hover:shadow dark:border-zinc-800 dark:bg-zinc-950"
            >
              {t}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search projects…"
            className="w-full rounded-xl border border-zinc-200 bg-white px-3 py-2 text-sm shadow-soft outline-none focus:ring-2 focus:ring-zinc-400 dark:border-zinc-800 dark:bg-zinc-950 dark:focus:ring-zinc-600 sm:w-72"
          />
          <Badge className="hidden sm:inline-flex">{filtered.length} shown</Badge>
        </div>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {filtered.map((p: Project) => (
          <ProjectCard key={p.slug} slug={p.slug} name={p.name} tagline={p.tagline} stack={p.stack} />
        ))}
      </div>
    </div>
  );
}
