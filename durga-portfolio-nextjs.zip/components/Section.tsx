import { Container } from "@/components/Container";
import { cn } from "@/lib/utils";

export function Section({
  id,
  title,
  subtitle,
  className,
  children,
}: {
  id?: string;
  title: string;
  subtitle?: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className={cn("py-14 sm:py-16", className)}>
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-semibold tracking-tight sm:text-3xl">{title}</h2>
          {subtitle ? <p className="mt-2 max-w-3xl text-zinc-600 dark:text-zinc-300">{subtitle}</p> : null}
        </div>
        {children}
      </Container>
    </section>
  );
}
