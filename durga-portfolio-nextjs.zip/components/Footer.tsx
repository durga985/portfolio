import { Container } from "@/components/Container";
import { profile } from "@/data/profile";

export function Footer() {
  return (
    <footer className="border-t border-zinc-200 py-10 dark:border-zinc-800">
      <Container className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-zinc-600 dark:text-zinc-400">
          © {new Date().getFullYear()} {profile.name}. Built with Next.js.
        </p>
        <div className="flex flex-wrap gap-4 text-sm">
          <a className="text-zinc-700 no-underline hover:underline dark:text-zinc-300" href={`mailto:${profile.email}`}>
            Email
          </a>
          <a
            className="text-zinc-700 no-underline hover:underline dark:text-zinc-300"
            href={`https://www.linkedin.com/in/${profile.linkedin}`}
            target="_blank"
            rel="noreferrer"
          >
            LinkedIn
          </a>
        </div>
      </Container>
    </footer>
  );
}
